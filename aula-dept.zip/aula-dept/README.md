# AULA/DEPT®

Proyecto académico de maquetación nivel 3 inspirado en la página BASIC/DEPT propuesta por Frontend Practice.

## Tecnologías
- HTML5
- CSS3
- JavaScript ES Modules

## Características
- Diseño responsive para computador, tablet y celular.
- Pantalla de carga inicial.
- Animaciones activadas por scroll usando IntersectionObserver.
- Menú móvil.
- Carrusel horizontal arrastrable con mouse o pantalla táctil.
- Efectos hover.
- Formulario de demostración.

## Cómo ejecutarlo
Por usar módulos de JavaScript, se recomienda abrirlo mediante un servidor local:

### Opción VS Code
Instalar la extensión **Live Server**, hacer clic derecho sobre `index.html` y seleccionar `Open with Live Server`.

### Opción Python
```bash
python -m http.server 5500
```
Luego abrir `http://localhost:5500`.

## Estructura
- `index.html`: estructura semántica de la página.
- `css/base`: reset, variables y tipografía.
- `css/components`: loader, navegación y botones.
- `css/sections`: estilos de las secciones principales.
- `js/components`: funciones independientes para menú, animaciones, slider y formulario.
- `js/main.js`: punto de entrada que inicializa las funciones.

## Rama sugerida
```bash
git checkout -b proyecto
git add .
git commit -m "feat: crear landing responsive inspirada en Basic"
git push -u origin proyecto
```
